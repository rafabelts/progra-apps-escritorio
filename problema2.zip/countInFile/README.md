# PROBLEMA 2
Escriba un programa que cuente el número de caracteres, palabras y líneas en un archivo. Las palabras están separadas por espacios en blanco. El nombre del archivo debe pasarse como un argumento de línea de comandos, como se muestra en el ejemplo:


How to run? <br>
java countInFile arg1
- arg1: texto para contar