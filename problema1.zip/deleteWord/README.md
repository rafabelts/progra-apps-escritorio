# PROBLEMA 1
Escribe un programa que elimina todas las apariciones de una cadena especificada de un archivo de texto. Por ejemplo, invocar

How to run? <br>
java deleteWord arg1 arg2
- arg1: Palabra a eliminar
- arg2: Archivo de donde se eliminara el arg1